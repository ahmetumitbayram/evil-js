import importlib

MODULES = {
        # File Name      Class Name
	'web_scraper'  : 'WebScraper',
        'dns_dumpster' : 'DNSDumpster',
	'crt_sh'       : 'CRTsh',       
	'trails'       : 'SecurityTrails'

    }

def get_module_class(name):
    cname = MODULES[name]
    modname = '.'.join([__name__, name])
    module = importlib.import_module(modname)
    return getattr(module, cname)
