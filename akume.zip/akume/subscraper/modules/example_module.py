import requests, json


def tldSorting(subdomains):
    pass


class ShodanIO():
    def __init__(self, args, target, handler):
        self.description = "Example module"
        self.author = '@m8r0wn'
        self.method = ['scrape']

        self.handler = handler
        self.target = target

    def tldSorting(self,subdomainList):
        localsortedlist = list()
        finallist = list()
        for item in subdomainList:
            Reverseddomain = ".".join(str(item).split('.')[::-1])
            localsortedlist.append(Reverseddomain)

        sortedlist = sorted(localsortedlist)

        for item in sortedlist:
            reReverseddomain = ".".join(str(item).split('.')[::-1])
            finallist.append(reReverseddomain)
        return finallist

    def execute(self):
        apikey = "OpxWSnevFM8bgqgcCUwbMnzUK8jKz2Oc"
        domain = self.target

        r = requests.get('https://api.shodan.io/dns/domain/' + domain + '?key=' + apikey)
        data = json.loads(r.text)
        subdomains = set()
        for item in data["data"]:
            entry = item["subdomain"]
            record_type = item["type"]
            value = item["value"]
            if record_type == 'CNAME' and domain in value:
                delim = value.split('.')
                match = delim[-2] + '.' + delim[-1]
                if match == domain:
                    subdomains.add(value)
        for s in tldSorting(subdomains):
            sub = s
            self.handler.sub_handler({'Name': sub, 'Source': 'Shodan-IO'})








