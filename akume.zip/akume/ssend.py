import sys
import os
import acunetix
import requests

if len(sys.argv) > 1:
    eee = open("domains.txt", 'r').read().splitlines()
    HOSTS = list((eee))
else:
    print("domains.txt required")
    exit()


for host in HOSTS:
    try:
        os.system("python acunetix.py " + "https://" + host);
    except:
        pass
