#!/usr/bin/env python3
import subscraper
subscraper.main()