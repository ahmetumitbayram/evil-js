from config import *

from pyacunetix import *

import requests 

import os



FILE_NAME = "last_vulnerabilities.txt"
SLACK_WEBHOOK_URL = 'https://hooks.slack.com/services/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'

KEYWORDS = ["sql", "scripting", "inclusion", "upload", "bypass", "server", "database", "execution", "injection", "traversal", "xss", "remote","arbitrary"]



acu = Acunetix(host, email, password, secure=False)



if not os.path.exists(FILE_NAME):

    known_vulnerabilities = []

else:

    with open(FILE_NAME, 'r') as f:

        known_vulnerabilities = f.read().splitlines()



new_vulnerabilities = []



def send_to_slack(message):

    payload = {

        "text": message

    }

    requests.post(SLACK_WEBHOOK_URL, json=payload)



# Tüm scan'leri çekiyoruz.

scans = acu.get_scans()



# ...



# Her bir scan için sonuçları kontrol ediyoruz.

for scan in scans["scans"]:

    scan_id = scan["scan_id"]

    session_id = acu.get_session_id_from_scan(scan_id)

    

    # Tüm sonuçları çekiyoruz.

    results = acu.get_all_results(scan_id, session_id)

    

    for vulnerability in results["vulnerabilities"]:

        

        # Zafiyetin confidence değerini kontrol ediyoruz

        confidence_value = vulnerability.get("confidence", 0)

        

        if confidence_value == 100:  # Sadece confidence değeri 100 olan zafiyetler için

            vulnerability_info = "Vulnerability Name: " + vulnerability["vt_name"] + " | Affected URL: " + vulnerability["affects_url"]

        

            if any(keyword in vulnerability["vt_name"].lower() for keyword in KEYWORDS) and vulnerability_info not in known_vulnerabilities and vulnerability_info not in new_vulnerabilities:

                print(vulnerability_info)

                send_to_slack(vulnerability_info)  # Slack'e bildirim gönder

                new_vulnerabilities.append(vulnerability_info)

                print("-" * 50)  # Ayırıcı bir satır ekliyoruz.



# ...





# Tamamlanmış taramalar için target'ları sil



completed_scans = acu.get_completed_scans()



for scan in completed_scans["scans"]:

    target_id = scan.get("target_id", None)

    if target_id:

        if acu.delete_target(target_id):

            print(f"Target {target_id} successfully deleted.")

        else:

            print(f"Failed to delete target {target_id}.")


failed_scans = acu.get_failed_scans()



for scan in failed_scans:



    target_id = scan.get("target_id", None)

    if target_id:

        if acu.delete_target(target_id):

            print(f"Target {target_id} successfully deleted.")

        else:

            print(f"Failed to delete target {target_id}.")


# Yeni bulunan zafiyetleri dosyaya yaz

with open(FILE_NAME, 'a') as f:

    for vuln in new_vulnerabilities:

        f.write(vuln + "\n")
