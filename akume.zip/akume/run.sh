#!/bin/bash

bash ./h1.sh

